# Integration Tool Decision Challenge — QuickCart Philippines

**System Integration and Architecture**
**Activity:** Integration Tool Decision Challenge
**Section:** BSIT 3 T2
**Group members:** Randolf Comonlay, Jezreel C. Talaid, Excel Jim Molina, Jasper Patagnan

## Task 1: Analyze the Existing Problems

| Business problem | Possible cause | Expected benefit of integration |
| --- | --- | --- |
| Slow order processing | Employees copy order details by hand from the online store into the inventory, payment and delivery systems, so each order waits for someone to handle it. | Each new order automatically triggers the next steps (stock check, payment check, courier booking), cutting processing time from minutes or hours to seconds. |
| Inaccurate inventory | Stock is updated manually and not in real time; typing errors, forgotten updates and two sales of the same item cause mismatches. | Stock is deducted automatically for every confirmed order and returned if the order is cancelled, so records stay accurate and overselling is prevented. |
| Delayed payment verification | Staff manually compare payments from the gateway or bank against orders, so verification depends on someone being available. | The payment gateway sends confirmation straight to the order system, so paid orders are marked and released for shipping automatically. |
| Late customer notifications | Messages are sent by hand only after staff finish updating each system, so customers are informed late or not at all. | Order, payment and shipping status changes automatically send email or SMS, keeping customers informed and reducing “where is my order?” inquiries. |
| Repetitive employee work | The four systems are separate and not connected, so people act as the “bridge” by copying and re-typing the same data. | Routine data entry is automated, so staff can focus on customer service, exceptions and growing the business, with fewer human errors. |

## Task 2: Compare the Integration Approaches

| Criteria | Option A: Workflow Automation | Option B: Direct API Integration | Option C: Enterprise Platform |
| --- | --- | --- | --- |
| Development time | Shortest. Ready-made connectors and drag-and-drop setup can work in days to a few weeks. | Longest of the small-scale options. Needs design, coding and testing, often weeks to months. | Long. Needs planning, setup, training and often outside specialists, usually months. |
| Initial cost | Low. Mostly a monthly subscription with no developer hiring. Estimate: ~200 orders/day is about 6,000 orders/month; at roughly 6–7 workflow steps per order that is about 40,000 credits/month, which needs a higher-volume tier than Make’s 10,000-credit starter plan (about US$10–11/month). Exact cost should be confirmed on the vendor’s pricing page. | Medium to high. Developer time is the main cost even though the REST APIs themselves may be free. | Highest. Licensing, implementation and consulting fees are likely beyond a small store’s budget. |
| Customization | Moderate. Good for common workflows, but limited by available connectors and tool features. | Highest. Business rules can be coded exactly as needed. | High, but through the platform’s own tools and standards. |
| Security control | Moderate. Depends on the vendor’s security; data passes through a third-party service, so access must be managed carefully. | Highest. The team controls authentication, encryption, validation and where data is stored (but must implement it correctly). | High. Strong built-in governance, access control and monitoring. |
| Scalability | Fair to good. Fine for hundreds of orders per day; higher volume raises plan costs and runs into usage limits. | Good if well designed. Can be scaled and optimized, but the team must handle it. | Excellent. Built for many systems and very high volumes. |
| Maintenance requirements | Low. The vendor maintains the platform; staff only adjust workflows and watch for connector changes. | High. Needs a developer to fix bugs, update for API changes and monitor. | Medium to high. Needs trained or specialized staff and ongoing licensing. |

**Note:** No option is always better. Option A is the best fit only because QuickCart is small, has a limited budget and needs fast results; Options B and C become more suitable as volume, customization needs and the number of systems increase.

## Task 3: Proposed Integration Diagram

![quickcart-flowchart-full.png](quickcart-flowchart-full.png)

*Figure: QuickCart order integration flowchart.*

**Components and connections**

- **Online Store → Integration Layer:** Sends new order details (items, customer, address and total).
- **Integration Layer ↔ Inventory Database:** Checks stock, deducts the quantity and receives the updated count.
- **Integration Layer ↔ Payment Gateway (GCash / Maya / Card):** Sends or receives a payment request/status and gets confirmation or failure.
- **Integration Layer ↔ Courier / Delivery Service:** Sends paid-order shipping details and receives a tracking number.
- **Integration Layer → Customer Notification (Email / SMS):** Sends order, payment and shipping-status messages.
- **Integration Layer → Staff Dashboard / Error Alerts:** Sends failure alerts to staff. The workflow layer uses triggers, filters, retries and logs.

### Information moving between systems

1. **New order:** The online store sends the order details (items, customer, address, total) to the integration layer.
2. **Inventory:** The integration layer checks available stock and deducts the quantity; the inventory database returns the updated count.
3. **Payment:** The layer requests or receives payment status from the gateway; the gateway returns a confirmation or failure.
4. **Delivery:** Once payment is confirmed, the layer sends the shipping details to the courier and receives a tracking number.
5. **Notifications:** Order received, payment confirmed and shipped/delivered messages are sent to the customer by email or SMS.

**Tasks that happen automatically:** Order intake, stock checking and deduction, payment confirmation, courier booking and tracking number retrieval, customer notifications, error logging and staff alerts.

**Tasks that remain manual:** Reviewing flagged or failed orders, refunds and disputes, out-of-stock decisions, and periodic reconciliation of inventory and payment records.

## Task 4: Recommendation to QuickCart’s Owner

**Recommendation:** We recommend Option A, workflow automation using a tool such as Make or Zapier, because QuickCart is a small, growing store with a limited budget and about 200 orders per day, and its problems come from manual, repetitive transfers between four systems rather than from complex logic. Ready-made connectors let us link the online store, inventory, payment gateway, courier and notifications in days instead of months, without hiring developers.

- **Top benefits:** Faster order processing, accurate real-time inventory, and automatic payment checking and customer notifications, which also free employees from repetitive work.
- **Limitations:** Monthly subscription fees, usage limits, dependence on available connectors, and less control over security and custom logic than direct code.
- **Growth path:** As QuickCart grows, we can add workflows, upgrade the plan, and use custom API calls for special cases; if volume or system complexity becomes very large, we can move to direct API integration or an enterprise platform.
- **Failure safeguards:** If an integration fails, we will protect the business with securely stored API keys with limited permissions, data validation, duplicate-order checks, error logging, automatic retries, alerts to staff, and a manual backup procedure with regular reconciliation of inventory and payments.

## Task 5: Group Presentation Outline (3–4 minutes)

| Part | Time | What we will say |
| --- | --- | --- |
| Business problem | 30 sec | QuickCart uses separate systems for orders, inventory, payments and deliveries. Employees copy data by hand, causing slow orders, wrong stock counts, delayed payment checks, late notifications and wasted staff time. |
| Integration diagram | 60 sec | A workflow automation layer sits in the middle. A new order from the online store triggers a stock check and deduction in the inventory database, a payment request and confirmation with the payment gateway, a booking with the courier, and automatic status messages to the customer. Failures go to a staff alert. |
| Justification | 60 sec | Option A fits QuickCart’s limited budget, small volume (about 200 orders/day), need for quick results and lack of a large developer team. Option B takes longer and costs more to build and maintain; Option C is more than a small store needs. |
| Risks and safeguards | 30–60 sec | Risks: subscription cost, usage limits, connector limits, reliance on a third party. Safeguards: secure API keys, data validation, duplicate prevention, logging, retries, staff alerts, manual backup and regular reconciliation. |

## Individual Reflection

### 1. What is the most important advantage of integration tools for QuickCart?

The most important advantage is that data moves between systems automatically and consistently. For QuickCart this means orders, stock, payments and notifications stay in sync without employees re-typing information, which makes processing faster, reduces mistakes and gives staff time for more valuable work.

### 2. Can integration tools create new problems even while solving existing ones? Explain.

Yes. A wrongly configured workflow can spread bad data to every connected system, a failed connection can silently stop orders or notifications, and duplicate triggers can create double orders or double stock deductions. Integration also adds dependence on a vendor, subscription costs, usage limits and new security risks, since API keys and customer data now pass through more places. That is why logging, validation, duplicate prevention, alerts and a manual backup plan are needed.

### 3. Would your recommendation change if QuickCart grew from 200 to 10,000 orders per day?

Probably yes. At 10,000 orders per day, workflow tools may become expensive because of per-task pricing and may hit usage or speed limits, and the business would need stronger reliability, monitoring and security. We would then consider direct API integration (if the company can hire developers) or an enterprise integration platform (if many systems must be managed centrally). The automation tool could still handle small side workflows.

### 4. What is more important: low cost, speed, security, or scalability?

For QuickCart right now, security is the most important, because the systems handle customer information and payments, and a breach or payment error would harm the business and customer trust far more than a slightly higher cost or slower setup. Cost, speed and scalability still matter, but they are trade-offs we can adjust, whereas lost customer data or money cannot easily be recovered. In practice, we choose the lowest-cost option that still meets a minimum level of security. Option A is still acceptable on security because the payment gateway (GCash, Maya or card provider) handles the actual card and wallet data so QuickCart never stores it, API keys are stored securely with limited permissions, and the workflow tool only passes the minimum order details between systems.